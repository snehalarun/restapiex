package com.example.DemartShoppingMall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemartShoppingMallApplicationTests {

	@Test
	void contextLoads() {
	}

}
