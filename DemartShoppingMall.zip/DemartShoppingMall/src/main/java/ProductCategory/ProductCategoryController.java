//package ProductCategory;
//
//import java.util.List;
//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.hibernate.Transaction;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequestMapping("api")
////@CrossOrigin("http://localhost:8080")
//public class ProductCategoryController {
//	
//
//		@Autowired
//		SessionFactory sf;
//		
//		@GetMapping("categories")
//		List<Category> allCategory()
//		{
//			Session session = sf.openSession();
//			List<Category> arraylist =session.createCriteria(Category.class).list();
//			return arraylist;
//		}
//		@GetMapping("products")
//		List<Product> allProduct()
//		{
//			Session session =sf.openSession();
//			List<Product> arraylist =session.createCriteria(Product.class).list();
//			return arraylist;
//		}
//		@GetMapping("category/{id}")
//		public Category getCategory(@PathVariable int id)
//		{
//			Session session= sf.openSession();
//			Category category= session.load(Category.class, id);
//			return category;
//		}
//		
//		@GetMapping("product/{id}")
//		public Product getProduct(@PathVariable int id)
//		{
//			Session session= sf.openSession();
//			Product product=session.load(Product.class, id);
//			return product;
//			
//		}
//		@PostMapping("addcategories")
//		public List<Category> addCategory(@RequestBody Category category)
//		{
//			Session session =sf.openSession();
//			Transaction tx =session.beginTransaction();
//			session.save(category);
//			tx.commit();
//			List<Category> list= allCategory();
//			return list;
//		}
//		@PostMapping("addproducts")
//		public List<Product> addProduct(@RequestBody Product product)
//		{
//			Session session =sf.openSession();
//			Transaction tx =session.beginTransaction();
//			session.save(product);
//			tx.commit();
//			List<Product> list= allProduct();
//			return list;
//		}
//		@DeleteMapping("category/{cid}")
//		public List<Category> deleteCategory(@PathVariable int cid )
//		{
//			Session session = sf.openSession();
//			Category category = session.load(Category.class, cid);
//			Transaction tx = session.beginTransaction();
//			session.delete(category);
//			tx.commit();
//			List<Category> list =allCategory();
//			return list;
//		}
//		@DeleteMapping("products/{pid}")
//		public List<Product> deleteProduct(@PathVariable int pid )
//		{
//			Session session = sf.openSession();
//			Product product = session.load(Product.class, pid);
//			Transaction tx = session.beginTransaction();
//			session.delete(product);
//			tx.commit();
//			List<Product> list =allProduct();
//			return list;
//		}
//		@PutMapping("updatecategory")
//		public List<Category> updateCategory(@RequestBody Category clientcategory)
//		{
//				
//				Session session = sf.openSession();
//
//				Transaction tx = session.beginTransaction();
//
//				session.saveOrUpdate(clientcategory);
//
//				tx.commit();
//
//				List<Category> list = allCategory();
//
//				return list;
//		}
//		@PutMapping("updateproduct")
//		public List<Product> updateCategory(@RequestBody Product clientproduct)
//		{
//				
//				Session session = sf.openSession();
//
//				Transaction tx = session.beginTransaction();
//
//				session.saveOrUpdate(clientproduct);
//
//				tx.commit();
//
//				List<Product> list = allProduct();
//
//				return list;
//		}
//
//
//	}
