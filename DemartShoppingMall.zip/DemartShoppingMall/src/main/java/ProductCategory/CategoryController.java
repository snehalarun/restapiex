package ProductCategory;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("categoryapi")
public class CategoryController 
{
	@Autowired
	SessionFactory factory;

	@GetMapping("category/{cid}")
	public Category getCategory(@PathVariable int cid)
	{
		Session session=factory.openSession();
		Category category=session.load(Category.class, cid);
		return category;	
	}

	@GetMapping("category")
	public List<Category> getAllCategory()
	{
		Session session=factory.openSession();		
		Query query=session.createQuery("from Category");
		List<Category> list=query.list();
		return list;
	}

	
	@PostMapping("category")
	public Category addCategory(@RequestBody Category category)
	{
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(category);
		transaction.commit();
		System.err.println("Category added into database");
		return category;
	}
	
	@PutMapping("category")
	public String updateCategory(@RequestBody Category clientcategory)
	{
		Session session=factory.openSession();
	
		        Category category=session.load(Category.class,clientcategory.getCid());
		        category.setCname(clientcategory.getCname());
		        //category.setProducts(clientcategory.getProducts());
				Transaction transaction=session.beginTransaction();
				session.update(category);
				transaction.commit();
				System.err.println(" record updated successfully...");
				return "Record Updated";

	}
	
	@DeleteMapping("category/{cid}")
	public String deleteCategory(@PathVariable int cid)
	{
		Session session=factory.openSession();
		Category category=session.load(Category.class, cid);
		Transaction transaction=session.beginTransaction();
		session.delete(category);
		transaction.commit();
		System.err.println(cid+" record deleted ");
		return "record deleted";
	}
	

}
